.mention-icon {
	display: inline-block;
}	
.mention-icon:before {
	content: "\f10d";
    font-family: FontAwesome;
    font-style: normal;
    font-weight: normal;
    font-size: 18px;
}
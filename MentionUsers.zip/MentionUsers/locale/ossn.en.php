<?php
 $en = array(
	'ossn:notifications:post:created' => '%s mentioned you in a post!',
	'ossn:notifications:created' => '%s mentioned you in a comment!'		
);
ossn_register_languages('en', $en); 